package com.yping.functiontools.fragment;

public class SocialFragment extends androidx.fragment.app.Fragment {
}
