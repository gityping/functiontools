package com.yping.functiontools.fragment;

public class ToolsFragment extends androidx.fragment.app.Fragment {
}
