package com.yping.functiontools;

import android.app.Application;

public class FunctionToolsApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
